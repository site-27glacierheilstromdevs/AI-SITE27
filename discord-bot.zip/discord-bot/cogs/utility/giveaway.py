"""
cogs/utility/giveaway.py  –  Giveaway System
giveaway, giveawaycreate, giveawaystart, giveawayend, giveawayreroll
"""
import asyncio
import json
import random
import discord
from discord.ext import commands, tasks
from datetime import datetime, timezone

from utils.helpers import (
    success_embed, error_embed, info_embed, warn_embed,
    parse_duration, format_duration, utcnow, discord_timestamp
)

GIVEAWAY_EMOJI = "🎉"


def giveaway_embed(prize: str, host: discord.Member, ends_at: datetime,
                   winners: int, entries: int, required_role: discord.Role = None,
                   ended: bool = False, winner_mentions: list = None) -> discord.Embed:
    if ended:
        color = 0x95A5A6
        title = "🎊 Giveaway Ended"
    else:
        color = 0xFF73FA
        title = f"{GIVEAWAY_EMOJI} GIVEAWAY {GIVEAWAY_EMOJI}"

    em = discord.Embed(title=title, description=f"## {prize}", color=color)
    em.add_field(name="Hosted by", value=host.mention)
    em.add_field(name="Winners", value=f"**{winners}** winner(s)")
    em.add_field(name="Entries", value=f"**{entries}** entries")

    if required_role:
        em.add_field(name="Required Role", value=required_role.mention, inline=False)

    if not ended:
        em.add_field(name="Ends", value=discord_timestamp(ends_at, "R"), inline=False)
        em.set_footer(text=f"Click {GIVEAWAY_EMOJI} to enter! | Ends")
        em.timestamp = ends_at
    else:
        if winner_mentions:
            em.add_field(
                name="🏆 Winners",
                value=", ".join(winner_mentions),
                inline=False
            )
        else:
            em.add_field(name="🏆 Winners", value="No valid entries.", inline=False)
        em.set_footer(text="Giveaway ended")
        em.timestamp = utcnow()

    return em


class Giveaway(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        self._check_giveaways.start()

    def cog_unload(self):
        self._check_giveaways.cancel()

    # ── Task: check expired giveaways ────────────────────────────
    @tasks.loop(seconds=15)
    async def _check_giveaways(self):
        now = utcnow().isoformat()
        rows = await self.db.fetchall(
            "SELECT * FROM giveaways WHERE status='active' AND ends_at <= ?", (now,)
        )
        for row in rows:
            await self._end_giveaway_auto(dict(row))

    @_check_giveaways.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()

    # ── Internal end ─────────────────────────────────────────────
    async def _end_giveaway_auto(self, row: dict):
        guild = self.bot.get_guild(int(row["guild_id"]))
        if not guild:
            await self.db.execute(
                "UPDATE giveaways SET status='ended' WHERE message_id=?", (row["message_id"],)
            )
            return

        channel = guild.get_channel(int(row["channel_id"]))
        if not channel:
            await self.db.execute(
                "UPDATE giveaways SET status='ended' WHERE message_id=?", (row["message_id"],)
            )
            return

        try:
            msg = await channel.fetch_message(int(row["message_id"]))
        except (discord.NotFound, discord.Forbidden):
            await self.db.execute(
                "UPDATE giveaways SET status='ended' WHERE message_id=?", (row["message_id"],)
            )
            return

        entries = json.loads(row["entries"] or "[]")
        winners_count = row["winners_count"]
        required_role_id = row["required_role"]

        # Filter valid entries
        valid_entries = []
        for uid in entries:
            member = guild.get_member(int(uid))
            if not member:
                continue
            if required_role_id:
                role = guild.get_role(int(required_role_id))
                if role and role not in member.roles:
                    continue
            valid_entries.append(uid)

        winners = random.sample(valid_entries, min(winners_count, len(valid_entries)))
        winner_mentions = [f"<@{w}>" for w in winners]

        # Fetch host
        try:
            host = await guild.fetch_member(int(row["host_id"]))
        except Exception:
            host = guild.me

        req_role = guild.get_role(int(required_role_id)) if required_role_id else None
        ends_at = datetime.fromisoformat(row["ends_at"]).replace(tzinfo=timezone.utc)

        em = giveaway_embed(
            prize=row["prize"],
            host=host,
            ends_at=ends_at,
            winners=winners_count,
            entries=len(entries),
            required_role=req_role,
            ended=True,
            winner_mentions=winner_mentions
        )
        await msg.edit(embed=em)

        if winners:
            await channel.send(
                f"🎊 Congrats {', '.join(winner_mentions)}! You won **{row['prize']}**!"
            )
        else:
            await channel.send(embed=warn_embed(f"No valid entries for **{row['prize']}**. No winner picked."))

        ended_at = utcnow().isoformat()
        await self.db.execute(
            "UPDATE giveaways SET status='ended', winners=?, ended_at=? WHERE message_id=?",
            (json.dumps(winners), ended_at, row["message_id"])
        )

    # ── Button view for entering ──────────────────────────────────
    async def _update_embed_entries(self, message_id: str, guild_id: str, entries: list):
        row = await self.db.fetchone(
            "SELECT * FROM giveaways WHERE message_id=? AND guild_id=?",
            (message_id, guild_id)
        )
        if not row:
            return
        guild = self.bot.get_guild(int(guild_id))
        if not guild:
            return
        ch = guild.get_channel(int(row["channel_id"]))
        if not ch:
            return
        try:
            msg = await ch.fetch_message(int(message_id))
        except Exception:
            return

        try:
            host = await guild.fetch_member(int(row["host_id"]))
        except Exception:
            host = guild.me

        req_role = guild.get_role(int(row["required_role"])) if row["required_role"] else None
        ends_at = datetime.fromisoformat(row["ends_at"]).replace(tzinfo=timezone.utc)
        em = giveaway_embed(
            prize=row["prize"], host=host, ends_at=ends_at,
            winners=row["winners_count"], entries=len(entries),
            required_role=req_role
        )
        await msg.edit(embed=em)

    # ── on_reaction for entering giveaway ────────────────────────
    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if str(payload.emoji) != GIVEAWAY_EMOJI:
            return
        if payload.user_id == self.bot.user.id:
            return

        row = await self.db.fetchone(
            "SELECT * FROM giveaways WHERE message_id=? AND status='active'",
            (str(payload.message_id),)
        )
        if not row:
            return

        entries = json.loads(row["entries"] or "[]")
        uid = str(payload.user_id)
        if uid not in entries:
            entries.append(uid)
            await self.db.execute(
                "UPDATE giveaways SET entries=? WHERE message_id=?",
                (json.dumps(entries), str(payload.message_id))
            )
            await self._update_embed_entries(str(payload.message_id), str(payload.guild_id), entries)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if str(payload.emoji) != GIVEAWAY_EMOJI:
            return
        row = await self.db.fetchone(
            "SELECT * FROM giveaways WHERE message_id=? AND status='active'",
            (str(payload.message_id),)
        )
        if not row:
            return
        entries = json.loads(row["entries"] or "[]")
        uid = str(payload.user_id)
        if uid in entries:
            entries.remove(uid)
            await self.db.execute(
                "UPDATE giveaways SET entries=? WHERE message_id=?",
                (json.dumps(entries), str(payload.message_id))
            )
            await self._update_embed_entries(str(payload.message_id), str(payload.guild_id), entries)

    # ─────────────────────────────────────────────────────────────
    # GIVEAWAYCREATE / GIVEAWAYSTART
    # Usage: !giveawaycreate #channel 1d 2 Nitro Classic
    # ─────────────────────────────────────────────────────────────
    @commands.command(aliases=["gcreate"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveawaycreate(self, ctx, channel: discord.TextChannel,
                              duration: str, winners: int, *, prize: str):
        """Create a giveaway. !giveawaycreate #channel 1d 1 Nitro"""
        td = parse_duration(duration)
        if not td:
            return await ctx.send(embed=error_embed("Invalid duration. Example: `1h`, `7d`, `30m`"))
        if winners < 1:
            return await ctx.send(embed=error_embed("Must have at least 1 winner."))

        ends_at = utcnow() + td
        em = giveaway_embed(
            prize=prize, host=ctx.author, ends_at=ends_at,
            winners=winners, entries=0
        )
        msg = await channel.send(content=f"**{GIVEAWAY_EMOJI} NEW GIVEAWAY {GIVEAWAY_EMOJI}**", embed=em)
        await msg.add_reaction(GIVEAWAY_EMOJI)

        await self.db.execute(
            """INSERT INTO giveaways
               (guild_id, channel_id, message_id, host_id, prize, winners_count, ends_at)
               VALUES (?,?,?,?,?,?,?)""",
            (str(ctx.guild.id), str(channel.id), str(msg.id),
             str(ctx.author.id), prize, winners, ends_at.isoformat())
        )
        await ctx.send(embed=success_embed(
            f"Giveaway started in {channel.mention}!\n"
            f"Prize: **{prize}** | Duration: **{format_duration(td)}** | Winners: **{winners}**"
        ))

    @commands.command(aliases=["gstart"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveawaystart(self, ctx, channel: discord.TextChannel,
                             duration: str, winners: int, *, prize: str):
        """Alias for giveawaycreate."""
        await ctx.invoke(self.giveawaycreate, channel=channel, duration=duration,
                         winners=winners, prize=prize)

    @commands.command(aliases=["g"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveaway(self, ctx, channel: discord.TextChannel,
                       duration: str, winners: int, *, prize: str):
        """Quick giveaway. !giveaway #channel 1h 1 Steam Gift Card"""
        await ctx.invoke(self.giveawaycreate, channel=channel, duration=duration,
                         winners=winners, prize=prize)

    # ─────────────────────────────────────────────────────────────
    # GIVEAWAYEND
    # ─────────────────────────────────────────────────────────────
    @commands.command(aliases=["gend"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveawayend(self, ctx, message_id: int):
        """End a giveaway early by message ID."""
        row = await self.db.fetchone(
            "SELECT * FROM giveaways WHERE message_id=? AND guild_id=? AND status='active'",
            (str(message_id), str(ctx.guild.id))
        )
        if not row:
            return await ctx.send(embed=error_embed("Active giveaway not found with that message ID."))
        await self._end_giveaway_auto(dict(row))
        await ctx.send(embed=success_embed("Giveaway ended manually."))

    # ─────────────────────────────────────────────────────────────
    # GIVEAWAYREROLL
    # ─────────────────────────────────────────────────────────────
    @commands.command(aliases=["greroll"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveawayreroll(self, ctx, message_id: int, winners: int = 1):
        """Reroll winners for an ended giveaway."""
        row = await self.db.fetchone(
            "SELECT * FROM giveaways WHERE message_id=? AND guild_id=? AND status='ended'",
            (str(message_id), str(ctx.guild.id))
        )
        if not row:
            return await ctx.send(embed=error_embed("Ended giveaway not found with that message ID."))

        entries = json.loads(row["entries"] or "[]")
        if not entries:
            return await ctx.send(embed=warn_embed("No entries to reroll from."))

        new_winners = random.sample(entries, min(winners, len(entries)))
        winner_mentions = [f"<@{w}>" for w in new_winners]
        await ctx.send(
            f"🎊 **Giveaway Reroll!** New winner(s) for **{row['prize']}**: {', '.join(winner_mentions)}!"
        )


async def setup(bot):
    await bot.add_cog(Giveaway(bot))
