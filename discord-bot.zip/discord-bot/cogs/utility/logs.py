"""
cogs/utility/logs.py  –  Server Event Logging System
Logs: member join/leave, message delete/edit, role changes,
      channel changes, bans, voice activity, nickname changes,
      invite tracking, bulk message delete.
Commands: logchannel, setlogchannel, antilogs
"""
import discord
from discord.ext import commands
from datetime import timezone

from utils.helpers import utcnow, discord_timestamp, has_admin_role


# ── Color palette ─────────────────────────────────────────────
C_JOIN    = 0x2ECC71   # green
C_LEAVE   = 0xE74C3C   # red
C_EDIT    = 0x3498DB   # blue
C_DELETE  = 0xE67E22   # orange
C_BAN     = 0x8B0000   # dark red
C_UNBAN   = 0x27AE60   # dark green
C_ROLE    = 0x9B59B6   # purple
C_CHANNEL = 0x1ABC9C   # teal
C_VOICE   = 0xF39C12   # yellow
C_NICK    = 0x95A5A6   # grey
C_INVITE  = 0x7289DA   # blurple
C_BULK    = 0xC0392B   # crimson


class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        # cache: guild_id -> log_channel_id (to avoid DB hit on every event)
        self._cache: dict[int, int | None] = {}

    async def get_log_channel(self, guild: discord.Guild) -> discord.TextChannel | None:
        gid = guild.id
        if gid not in self._cache:
            row = await self.db.fetchone(
                "SELECT log_channel_id FROM guilds WHERE guild_id=?", (str(gid),)
            )
            self._cache[gid] = int(row["log_channel_id"]) if row and row["log_channel_id"] else None

        ch_id = self._cache.get(gid)
        if not ch_id:
            return None
        return guild.get_channel(ch_id)

    def invalidate_cache(self, guild_id: int):
        self._cache.pop(guild_id, None)

    async def send_log(self, guild: discord.Guild, embed: discord.Embed):
        """Check antilogs toggle, then send."""
        row = await self.db.fetchone(
            "SELECT antilog_enabled FROM guilds WHERE guild_id=?", (str(guild.id),)
        )
        if row and row["antilog_enabled"]:
            return
        ch = await self.get_log_channel(guild)
        if ch:
            try:
                await ch.send(embed=embed)
            except (discord.Forbidden, discord.HTTPException):
                pass

    # ─────────────────────────────────────────────────────────────
    # COMMANDS
    # ─────────────────────────────────────────────────────────────
    @commands.command(aliases=["setlogchannel"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def logchannel(self, ctx, channel: discord.TextChannel = None):
        """Set the log channel. Leave blank to disable."""
        if channel is None:
            await self.db.execute(
                "UPDATE guilds SET log_channel_id=NULL WHERE guild_id=?", (str(ctx.guild.id),)
            )
            self.invalidate_cache(ctx.guild.id)
            return await ctx.send(embed=discord.Embed(description="✅ Log channel **disabled**.", color=C_DELETE))

        await self.db.execute(
            """INSERT INTO guilds(guild_id, log_channel_id) VALUES(?,?)
               ON CONFLICT(guild_id) DO UPDATE SET log_channel_id=excluded.log_channel_id""",
            (str(ctx.guild.id), str(channel.id))
        )
        self.invalidate_cache(ctx.guild.id)
        await ctx.send(embed=discord.Embed(
            description=f"✅ Log channel set to {channel.mention}.", color=C_JOIN
        ))

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def antilogs(self, ctx):
        """Toggle logging on/off."""
        row = await self.db.get_guild(ctx.guild.id)
        current = row.get("antilog_enabled", 0)
        new_val = 0 if current else 1
        await self.db.execute(
            "UPDATE guilds SET antilog_enabled=? WHERE guild_id=?",
            (new_val, str(ctx.guild.id))
        )
        state = "disabled ❌" if new_val else "enabled ✅"
        await ctx.send(embed=discord.Embed(description=f"Logging is now **{state}**.", color=C_ROLE))

    # ─────────────────────────────────────────────────────────────
    # MEMBER JOIN
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        em = discord.Embed(
            title="📥 Member Joined",
            color=C_JOIN,
            timestamp=utcnow()
        )
        em.set_thumbnail(url=member.display_avatar.url)
        em.add_field(name="User", value=f"{member.mention} (`{member}` | `{member.id}`)")
        em.add_field(name="Account Created", value=discord_timestamp(member.created_at, "R"), inline=False)
        em.add_field(name="Server Member Count", value=str(member.guild.member_count))
        em.set_footer(text=f"ID: {member.id}")
        await self.send_log(member.guild, em)

    # ─────────────────────────────────────────────────────────────
    # MEMBER LEAVE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        em = discord.Embed(
            title="📤 Member Left",
            color=C_LEAVE,
            timestamp=utcnow()
        )
        em.set_thumbnail(url=member.display_avatar.url)
        em.add_field(name="User", value=f"{member.mention} (`{member}` | `{member.id}`)")
        roles = [r.mention for r in member.roles if r.id != member.guild.id]
        em.add_field(name="Roles", value=", ".join(roles) if roles else "None", inline=False)
        if member.joined_at:
            em.add_field(name="Was a member for", value=discord_timestamp(member.joined_at, "R"))
        em.set_footer(text=f"ID: {member.id}")
        await self.send_log(member.guild, em)

    # ─────────────────────────────────────────────────────────────
    # MESSAGE DELETE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        em = discord.Embed(
            title="🗑️ Message Deleted",
            color=C_DELETE,
            timestamp=utcnow()
        )
        em.add_field(name="Author", value=f"{message.author.mention} (`{message.author}`)")
        em.add_field(name="Channel", value=message.channel.mention)
        if message.content:
            em.add_field(name="Content", value=message.content[:1024], inline=False)
        if message.attachments:
            em.add_field(name="Attachments", value="\n".join(a.url for a in message.attachments), inline=False)
        em.set_footer(text=f"User ID: {message.author.id} | Msg ID: {message.id}")
        await self.send_log(message.guild, em)

    # ─────────────────────────────────────────────────────────────
    # BULK MESSAGE DELETE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: list[discord.Message]):
        if not messages or not messages[0].guild:
            return
        guild = messages[0].guild
        channel = messages[0].channel
        em = discord.Embed(
            title="🗑️ Bulk Message Delete",
            color=C_BULK,
            timestamp=utcnow()
        )
        em.add_field(name="Channel", value=channel.mention)
        em.add_field(name="Messages Deleted", value=str(len(messages)))
        em.set_footer(text=f"Channel ID: {channel.id}")
        await self.send_log(guild, em)

    # ─────────────────────────────────────────────────────────────
    # MESSAGE EDIT
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if not before.guild or before.author.bot:
            return
        if before.content == after.content:
            return
        em = discord.Embed(
            title="✏️ Message Edited",
            color=C_EDIT,
            timestamp=utcnow(),
            url=after.jump_url
        )
        em.add_field(name="Author", value=f"{before.author.mention} (`{before.author}`)")
        em.add_field(name="Channel", value=before.channel.mention)
        em.add_field(name="Before", value=before.content[:1024] or "*empty*", inline=False)
        em.add_field(name="After", value=after.content[:1024] or "*empty*", inline=False)
        em.set_footer(text=f"User ID: {before.author.id} | Msg ID: {before.id}")
        await self.send_log(before.guild, em)

    # ─────────────────────────────────────────────────────────────
    # MEMBER BAN
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        em = discord.Embed(title="🔨 Member Banned", color=C_BAN, timestamp=utcnow())
        em.set_thumbnail(url=user.display_avatar.url)
        em.add_field(name="User", value=f"{user.mention} (`{user}` | `{user.id}`)")
        em.set_footer(text=f"ID: {user.id}")
        await self.send_log(guild, em)

    # ─────────────────────────────────────────────────────────────
    # MEMBER UNBAN
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        em = discord.Embed(title="✅ Member Unbanned", color=C_UNBAN, timestamp=utcnow())
        em.set_thumbnail(url=user.display_avatar.url)
        em.add_field(name="User", value=f"{user.mention} (`{user}` | `{user.id}`)")
        em.set_footer(text=f"ID: {user.id}")
        await self.send_log(guild, em)

    # ─────────────────────────────────────────────────────────────
    # MEMBER UPDATE (roles, nickname)
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        # Nickname change
        if before.nick != after.nick:
            em = discord.Embed(title="📝 Nickname Changed", color=C_NICK, timestamp=utcnow())
            em.set_thumbnail(url=after.display_avatar.url)
            em.add_field(name="User", value=f"{after.mention} (`{after}`)")
            em.add_field(name="Before", value=before.nick or "*none*")
            em.add_field(name="After", value=after.nick or "*none*")
            em.set_footer(text=f"ID: {after.id}")
            await self.send_log(after.guild, em)

        # Role changes
        added_roles = [r for r in after.roles if r not in before.roles]
        removed_roles = [r for r in before.roles if r not in after.roles]

        if added_roles:
            em = discord.Embed(title="➕ Role Added", color=C_ROLE, timestamp=utcnow())
            em.add_field(name="User", value=f"{after.mention} (`{after}`)")
            em.add_field(name="Role(s) Added", value=", ".join(r.mention for r in added_roles), inline=False)
            em.set_footer(text=f"ID: {after.id}")
            await self.send_log(after.guild, em)

        if removed_roles:
            em = discord.Embed(title="➖ Role Removed", color=C_ROLE, timestamp=utcnow())
            em.add_field(name="User", value=f"{after.mention} (`{after}`)")
            em.add_field(name="Role(s) Removed", value=", ".join(r.mention for r in removed_roles), inline=False)
            em.set_footer(text=f"ID: {after.id}")
            await self.send_log(after.guild, em)

    # ─────────────────────────────────────────────────────────────
    # VOICE STATE UPDATE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member,
                                    before: discord.VoiceState, after: discord.VoiceState):
        em = discord.Embed(color=C_VOICE, timestamp=utcnow())
        em.set_thumbnail(url=member.display_avatar.url)

        if before.channel is None and after.channel:
            em.title = "🔊 Joined Voice Channel"
            em.add_field(name="User", value=f"{member.mention} (`{member}`)")
            em.add_field(name="Channel", value=after.channel.mention)
        elif before.channel and after.channel is None:
            em.title = "🔇 Left Voice Channel"
            em.add_field(name="User", value=f"{member.mention} (`{member}`)")
            em.add_field(name="Channel", value=before.channel.mention)
        elif before.channel != after.channel:
            em.title = "🔄 Switched Voice Channel"
            em.add_field(name="User", value=f"{member.mention} (`{member}`)")
            em.add_field(name="From", value=before.channel.mention)
            em.add_field(name="To", value=after.channel.mention)
        elif before.self_mute != after.self_mute:
            em.title = "🔇 Self-Mute" if after.self_mute else "🎙️ Self-Unmute"
            em.add_field(name="User", value=f"{member.mention} (`{member}`)")
        elif before.self_deaf != after.self_deaf:
            em.title = "🔕 Self-Deafen" if after.self_deaf else "🔔 Self-Undeafen"
            em.add_field(name="User", value=f"{member.mention} (`{member}`)")
        else:
            return

        em.set_footer(text=f"ID: {member.id}")
        await self.send_log(member.guild, em)

    # ─────────────────────────────────────────────────────────────
    # CHANNEL CREATE / DELETE / UPDATE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        em = discord.Embed(title="📢 Channel Created", color=C_CHANNEL, timestamp=utcnow())
        em.add_field(name="Name", value=channel.mention)
        em.add_field(name="Type", value=str(channel.type).replace("_", " ").title())
        em.add_field(name="Category", value=channel.category.name if channel.category else "None")
        em.set_footer(text=f"ID: {channel.id}")
        await self.send_log(channel.guild, em)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        em = discord.Embed(title="🗑️ Channel Deleted", color=C_DELETE, timestamp=utcnow())
        em.add_field(name="Name", value=f"#{channel.name}")
        em.add_field(name="Type", value=str(channel.type).replace("_", " ").title())
        em.add_field(name="Category", value=channel.category.name if channel.category else "None")
        em.set_footer(text=f"ID: {channel.id}")
        await self.send_log(channel.guild, em)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        changes = []
        if before.name != after.name:
            changes.append(f"**Name:** `#{before.name}` → `#{after.name}`")
        if isinstance(before, discord.TextChannel) and before.topic != after.topic:
            changes.append(f"**Topic:** `{before.topic or 'None'}` → `{after.topic or 'None'}`")
        if isinstance(before, discord.TextChannel) and before.slowmode_delay != after.slowmode_delay:
            changes.append(f"**Slowmode:** `{before.slowmode_delay}s` → `{after.slowmode_delay}s`")
        if not changes:
            return
        em = discord.Embed(title="⚙️ Channel Updated", color=C_CHANNEL, timestamp=utcnow())
        em.add_field(name="Channel", value=after.mention)
        em.add_field(name="Changes", value="\n".join(changes), inline=False)
        em.set_footer(text=f"ID: {after.id}")
        await self.send_log(after.guild, em)

    # ─────────────────────────────────────────────────────────────
    # ROLE CREATE / DELETE / UPDATE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        em = discord.Embed(title="✨ Role Created", color=C_ROLE, timestamp=utcnow())
        em.add_field(name="Role", value=role.mention)
        em.add_field(name="Color", value=str(role.color))
        em.set_footer(text=f"ID: {role.id}")
        await self.send_log(role.guild, em)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        em = discord.Embed(title="🗑️ Role Deleted", color=C_DELETE, timestamp=utcnow())
        em.add_field(name="Role", value=role.name)
        em.add_field(name="Color", value=str(role.color))
        em.set_footer(text=f"ID: {role.id}")
        await self.send_log(role.guild, em)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        changes = []
        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")
        if before.color != after.color:
            changes.append(f"**Color:** `{before.color}` → `{after.color}`")
        if before.hoist != after.hoist:
            changes.append(f"**Hoisted:** `{before.hoist}` → `{after.hoist}`")
        if before.mentionable != after.mentionable:
            changes.append(f"**Mentionable:** `{before.mentionable}` → `{after.mentionable}`")
        if not changes:
            return
        em = discord.Embed(title="⚙️ Role Updated", color=C_ROLE, timestamp=utcnow())
        em.add_field(name="Role", value=after.mention)
        em.add_field(name="Changes", value="\n".join(changes), inline=False)
        em.set_footer(text=f"ID: {after.id}")
        await self.send_log(after.guild, em)

    # ─────────────────────────────────────────────────────────────
    # GUILD UPDATE (server settings change)
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        changes = []
        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")
        if before.verification_level != after.verification_level:
            changes.append(f"**Verification:** `{before.verification_level}` → `{after.verification_level}`")
        if before.afk_channel != after.afk_channel:
            changes.append(f"**AFK Channel:** `{getattr(before.afk_channel,'name','None')}` → `{getattr(after.afk_channel,'name','None')}`")
        if not changes:
            return
        em = discord.Embed(title="⚙️ Server Updated", color=C_CHANNEL, timestamp=utcnow())
        em.add_field(name="Changes", value="\n".join(changes), inline=False)
        await self.send_log(after, em)

    # ─────────────────────────────────────────────────────────────
    # INVITE CREATE / DELETE
    # ─────────────────────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_invite_create(self, invite: discord.Invite):
        em = discord.Embed(title="🔗 Invite Created", color=C_INVITE, timestamp=utcnow())
        em.add_field(name="Code", value=f"`{invite.code}`")
        em.add_field(name="Created by", value=invite.inviter.mention if invite.inviter else "Unknown")
        em.add_field(name="Channel", value=invite.channel.mention if invite.channel else "Unknown")
        em.add_field(name="Max Uses", value=str(invite.max_uses) if invite.max_uses else "Unlimited")
        em.add_field(name="Expires", value=discord_timestamp(invite.expires_at, "R") if invite.expires_at else "Never")
        await self.send_log(invite.guild, em)

    @commands.Cog.listener()
    async def on_invite_delete(self, invite: discord.Invite):
        em = discord.Embed(title="🗑️ Invite Deleted", color=C_DELETE, timestamp=utcnow())
        em.add_field(name="Code", value=f"`{invite.code}`")
        em.add_field(name="Channel", value=invite.channel.mention if invite.channel else "Unknown")
        await self.send_log(invite.guild, em)


async def setup(bot):
    await bot.add_cog(Logs(bot))
