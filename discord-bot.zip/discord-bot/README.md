# 🤖 Discord Bot

Bot Discord lengkap dengan Moderation, Music, dan Utility.  
Hosting: **NexusHost** | Language: **Python 3.11+**

## 📁 Struktur
```
discord-bot/
├── main.py              # Entry point
├── bot.py               # Bot class
├── requirements.txt
├── .env.example
├── cogs/
│   ├── moderation/mod.py     # 30+ mod commands
│   ├── music/music.py        # 15+ music commands
│   └── utility/
│       ├── utility.py        # 40+ utility commands
│       ├── giveaway.py       # Giveaway system
│       └── logs.py           # Channel logging
├── database/
│   ├── db.py                 # Async DB manager
│   └── schema.sql            # Full SQL schema
└── utils/helpers.py
```

## 🚀 Setup NexusHost
1. Upload semua file ke NexusHost (atau connect GitHub repo)
2. Set **main file**: `main.py`
3. Set **Python version**: 3.11
4. Di panel NexusHost, tambahkan **Environment Variables**:
   - `TOKEN` = bot token dari Discord Developer Portal
   - `WEATHER_API_KEY` = (optional) OpenWeatherMap
   - `GENIUS_API_KEY` = (optional) Genius Lyrics
5. Klik **Start**

## ⚙️ Setup Discord Bot
1. Buka [Discord Developer Portal](https://discord.com/developers/applications)
2. New Application → Bot → Reset Token → copy TOKEN
3. Enable **ALL Privileged Intents** (Presence, Server Members, Message Content)
4. Invite bot dengan permission `Administrator`

## 📋 Commands

### Moderation
`kick` `ban` `unban` `softban` `mute` `unmute` `timeout` `untimeout`  
`warn` `unwarn` `clearwarn` `warnings` `clear` `lockchannel` `unlockchannel`  
`slowmode` `deafen` `undeafen` `setnick` `resetnick` `addrole` `removerole`  
`delrole` `move` `voicekick` `voiceban` `case` `cases` `reason` `duration`  
`modlog` `modlogs`

### Music
`play` `pause` `resume` `stop` `skip` `skipto` `queue` `np` `volume`  
`leave` `remove` `clearqueue` `loop` `shuffle` `lyrics` `search`

### Utility
`ping` `stats` `about` `prefix` `invite` `support`  
`avatar` `userinfo` `serverinfo` `roleinfo` `channelinfo`  
`say` `announce` `announcehere` `calc` `flip` `roll` `choose` `8ball`  
`joke` `cat` `dog` `pug` `translate` `urban` `define` `weather` `time` `date`  
`afk` `afkset` `afkremove` `rank` `ranks` `addrank` `delrank` `playtime`  
`giveaway` `giveawaycreate` `giveawaystart` `giveawayend` `giveawayreroll`  
`logchannel` `setlogchannel` `antilogs`

## 🛠️ Troubleshooting NexusHost
- **FileNotFoundError logs/**: Sudah fixed, folder auto-dibuat
- **WARNING duplicate packages**: Aman, itu cuma warning bukan error
- **Missing TOKEN**: Set di Environment Variables panel NexusHost
